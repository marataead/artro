<?
if(!empty($_POST)){
  $fio = $_POST['fio'];
  $phone = $_POST['phone'];

  $token = 'HPwbyoEuXuFD9CckauCfVS';
  $secret = 'iseYRaUxtDVEAqbQ2lQJtX';

  $data = [
      'fio' => $fio,
      'phone' => $phone,
      'product_id' => 127,
      'traffic_flow_id' => 43409,
      'pay_action' => 'confirmed',
      'language' => 'rus',
      'price' => '1696.00',
      'special_price' => '0',
      'country' => 'ru',
      'ip' => $_SERVER['REMOTE_ADDR'],
  ];

  $dataSign = sha1(json_encode([$secret, $data]));

  $request = json_encode([
      'token' => $token,
      'data' => $data,
      'dataSign' => $dataSign,
  ]);

  $ch = curl_init();

  curl_setopt($ch, CURLOPT_URL, 'http://api.omnicpa.com/api/User/3.0/createOrder');
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, [
      'request' => $request,
  ]);

  $result = curl_exec($ch);
  curl_close($ch);

  header('Location: /success.php');
  exit();
  }
?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,minimum-scale=0.25,maximum-scale=4.0,user-scalable=no">
<title>Вылечите суставы, пока вы не сели в инвалидное кресло! Запомните: артрит и артроз разрушают хрящевую ткань за 3
    года</title>
<link href="web/zzb/css/reset.css" rel="stylesheet">
<link href="web/zzb/css/index.css?v=1" rel="stylesheet">
<link href="web/zzb/_shared/css/politic.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="web/css/geo_comebacker.css">
<link rel="shortcut icon" href="/empty.ico" type="image/x-icon">
<script type="text/javascript" src="add/js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="add/js/date_random.2.03.js"></script>
</head>
<body>
<style>
    .pl_dat_code_block {
        display: none !important;
    }
</style>
<script type="text/javascript" src="add/js/jquery.blockUI.min.js"></script>
<script type="text/javascript" src="add/js/promo_widgets_v2.js?v=12"></script>
<link type="text/css" rel="stylesheet" href="add/css/promo_v2.css?v=12">
<script src="add/inputmask_4_x/jquery.inputmask.bundle.min.js"></script>
<script src="add/inputmask_4_x/inputmask/phone-codes/phone.simple.js?v=13"></script>
<script type="text/javascript" src="add/js/localization/rus.js?v=13"></script>
<style> 
    @media screen and (max-width: 720px) {
.header-top-left{
      float: none;
    text-align: center;
    margin: 0 auto;
    display: block;
        width: fit-content;
}

  }
    body {
      position: relative;
      -webkit-animation-name: fadeInLoad; /* Chrome, Safari, Opera */
      -webkit-animation-duration: 1.6s; /* Chrome, Safari, Opera */
      animation-name: fadeInLoad;
      animation-duration: 1.6s;
    }

    /* Chrome, Safari, Opera */
    @-webkit-keyframes fadeInLoad {
      0% {opacity: 0;}
      25% {opacity: 0;}
      50% {opacity:0;}
      75% {opacity:0.9;}
      100% {opacity:1;}
    }

    /* Standard syntax */
    @keyframes fadeInLoad {
      0% {opacity: 0;}
      25% {opacity: 0;}
      50% {opacity:0;}
      75% {opacity:0.9;}
      100% {opacity:1;}
    }
  </style>
<style>
    .pl_field_address_info {
      margin: 0 !important;
      padding: 0 !important;
      border: none !important;
      outline: none !important;
      position: absolute;
      z-index: -1;
      width: 0px !important;
      height: 0px !important;
    }

    .subtitle {
      line-height: 1.3;
      margin-bottom: 20px;
    }

    .header-top-container {
      padding: 1px 2% 0px;
    }

    .content-right {
      position: sticky;
      top: 0px;
    }

    form button {
      transition: background-color 300ms linear;
    }

    form button:hover {
      background: rgb(96 149 2);
    }

    @media screen and (max-width: 769px) {
      .header-top-container {
        padding: 1px 2% 8px !important;
      }
    }

    @media screen and (max-width: 479px) {
      form button {
        font-size: 17px;
      }
    } 
  </style>
<div class="header">
<div class="header-top">
<div class="header-top-container" style="padding: 1px 2% 0px;">
<div class="header-top-left">
<div class="header-top-left-logo">
<img src="web/zzb/img/logo_kz.png" alt="Министерство Здравоохранения России" style="width: 100px;">
</div>
<div class="header-top-left-text"></div>
</div>
<div class="header-top-right">
<div class="header-top-right-text">
<ul>
<li>Русский</li>
<li class="separate">/</li>
<li><a href="">English</a></li>
</ul>
 </div>
<div class="header-top-right-search">
<form>
<a href=""><input class="input-search" type="search" name="search" placeholder="Поиск"></a>
</form>
</div>
</div>
</div>
</div>
<div class="header-bottom" style="background-color:#3043e1;">
<div class="header-bottom-container">
<ul>
<li><a href="">Здоровье</a></li>
<li><a href="">Деятельность</a></li>
<li><a href="">Документы</a></li>
<li><a href="">Пресс-центр</a></li>
<li><a href="">Конкурсы</a></li>
</ul>
</div>
</div>
</div>
<div class="content">
<div class="content-left">
<br>
<h1 style="text-transform:uppercase;">
<center><b>Вылечите суставы, пока вы не сели в инвалидное кресло! Запомните: артрит и артроз разрушают хрящевую
ткань за 3 года</b></center>
</h1>
 <br>
<p style="font-size:18px; text-align: center;"><i><b>Александр Леонидович Мясников, врач высшей медицинской
категории, рассказывает о том, как бесплатно <font color="red">вылечить суставы и наконец забыть о
мучительной боли!</font></b></i></p>
<div class="content-left-doctor">
<img src="web/zzb/img/ntv_.jpeg" style="width:100%">
<div class="content-left-doctor-text" style="width:100%;">
<strong>
Александр Леонидович Мясников
</strong>
главный врач Московской городской клинической больницы № 71 и Кремлёвской больницы Управления делами
Президента РФ. Участник и ведущий медицинских программ на телевидении и радио.
<br>
<br>
Лечебная практика – более 35 лет.
</div>
</div>
<br>
<p>
Каждый год врачи по всему миру отмечают плачевный факт: те болезни, которые раньше были присущи только старости,
стремительно молодеют. Если раньше на боли в спине и коленях жаловались пенсионеры, то сейчас все чаще
обращаются люди слегка за 30. <br>
Малоподвижный образ жизни, стрессы, обилие соли и сахара в пище - все это размягчает хрящевую ткань, изнашивая и
истончая ее. От каждого нового движения хрящ стирается и деформируется, кости начинают буквально “скрести” друг
о друга, вызывая болевой шок.
</p>
<br>
<div style="text-align:center;">
<img style="max-width: 500px; width: 100%" src="web/zzb/img/11122.png" alt="image" />
</div>
<br>
<p><b>Статистика такова, что более 45% людей в возрасте старше 35 лет имеют заболевания суставов! Все начинается с
малого: где-то перенапряглись, где-то подняли тяжести, где-то просто продуло шею. Сустав устроен так, что
основные проблемы начинаются с воспаления суставной жидкости, далее происходит размягчение хряща, и в
результате - инвалидность.</b></p>
<p><b>Заболевание суставов развивается стремительно.</b></p>
<br>
<p><b style="border-bottom: 2px solid #989898;
    border-bottom-color: #989898;" class="b">Нажмите ниже, чтобы открыть фотографии:</b></p>
<br>
<b>
<details>
<summary>
На фото руки пациентки в момент первой жалобы на боли в пальцах и спустя 2 года при неграмотном лечении.
</summary><br>
<img src="web/zzb/img/112.png"><br>
</details>
</b> <br>
<b>
<details>
<summary>
Фото пациента, попавшего ко мне с застарелым артритом коленного сустава. С его слов, от первых болевых
ощущений до невозможности наступать на ногу прошло не более месяца.
</summary><br>
<img src="web/zzb/img/113.png"><br>
</details>
</b> <br>
<b>
<details>
<summary>
Запущенный остеоартроз с присвоением инвалидности.
</summary><br>
<img src="web/zzb/img/114.png"><br>
</details>
</b><br>
<img src="web/zzb/img/hqdefault.jpeg" alt="" style="float: left; max-width: 400px; width: 100%; margin-right: 12px;">
<p> К сожалению, многие пациенты пропускают первые симптомы заболевания, пуская все на самотек. Самое страшное, с
чем я сталкиваюсь в своей практике - это самолечение, зачастую самыми абсурдными и неэффективными средствами:
оборачивание суставов капустным листом, йодовая сеточка… не буду перечислять, чтобы не распространять эту
глупость дальше.
<b>Во всем этом стоит помнить одну важную вещь: заболевания суставов доведут вас до инвалидного кресла менее чем
за 3 года!</b>
</p>
<br>
<p>Болезнь развивается так: </p>
<p>Воспаление суставной жидкости - размягчение хряща и его истончение - острый болевой синдром - потеря
способности двигаться.</p>
<p style="color: red;">При неграмотном и несвоевременном лечении существует только одно развитие событий!</p>
<p>Как врач, своим долгом я считаю информировать всех о первых проявлениях артритов. Предупрежден – значит
вооружен!</p>
<p>Я советую каждому: проверьте себя на симптомы, и если вы найдете совпадения – НЕМЕДЛЕННО НАЧИНАЙТЕ ЛЕЧЕНИЕ!
</p>
<ul style="padding-left: 10px;">
Симптомы:
<li>* Боль при сгибании суставов.</li>
<li>* Онемение пальцев рук или ног.</li>
<li>* Хруст при потягивании.</li>
<li>* Опухоль и покраснение сустава.</li>
<li>* Ощущение песка в суставах.</li>
<li>* Беспричинное повышение температуры.</li>
</ul>
<p>Запомните, заболевание прогрессирует в разы быстрее, если у вас присутствует избыточный вес, так как в данном
случае происходит двойная нагрузка на суставы.</p> <br>
<p>А теперь, только представьте: В АПТЕКАХ НЕТ СРЕДСТВА, ИЗЛЕЧИВАЮЩЕГО СУСТАВЫ!</p> <br>
<div style="text-align:center;">
<img style="max-width: 700px; width: 100%" src="web/zzb/img/ntv1.jpg" alt="image" />
</div>
<p>Фармацевтические компании тратят миллионы на разработку средств, которые помогают облегчить боль и даже снять
воспаление. Эти средства окупаются и приносят миллиарды прибыли. Но НИ ОДНА МЕДИЦИНСКАЯ КОРПОРАЦИЯ НЕ ХОЧЕТ
РАЗРАБАТЫВАТЬ ЛЕКАРСТВА, ВЛИЯЮЩИЕ НА ПРИЧИНУ АРТРИТОВ И АРТРОЗОВ! ОНИ ПРОСТО НЕ ХОТЯТ, ЧТОБЫ ВЫ ИЗЛЕЧИЛИСЬ!</p>
<h3 style="color: grey; font-size: 20px">А теперь я расскажу вам, как можно вернуть своим суставам здоровье!</h3>
<br>
<img src="web/zzb/img/zdorov-official.png" alt="" style="float: left; max-width: 180px; width: 100%; margin-right: 12px;">
<p>Дело в том, что российскими учеными разработано уникальное средство, которое влияет на причину болей в
суставах, причем, средство, основанное на природных компонентах! <b>В обход химии удалось добиться уникального
сочетания трав и экстрактов, главное из них это&nbsp;- запатентованная формула на основе хондроитина и
коллагена, которые, действуя сообща, позволяют не только снять болевой синдром и воспаление,
но и заставить хрящевую ткань регенерировать!</b></p>
<p>В основе этих технологий лежат более 30 лет исследований института биофизики РАН, на исследования и разработку
потрачено более 246&nbsp;миллионов рублей!</p>
<p>Гиганты фармацевтики делают все возможное, чтобы не допустить появление геля Артодол в аптечных сетях, но его
эффективность так велика, что средство уже начинает набирать обороты среди врачей и пациентов.</p><br><br>
<h3 style="color: red; font-size: 18px; font-weight: 900;"> Александр Мясников: Я лично до <span class="nowdate" format="dayF.monthF.year"></span> включительно, совершенно бесплатно отправлю всем
читателям гель Артодол для восстановления суставов!</h3> <br>
<p><em><b>Просто укажите ваше имя и номер телефона в форме внизу. Заявка передается консультантам, у них вы
сможете узнать&nbsp;- подойдет ли Артодол для лечения вашей проблемы, получите ответы на интересующие вопросы и
уточните о возможности бесплатного получения.</b></em></p>
<div style="text-align:center;">
<a href=""><img style="max-width: 500px; width: 80%" src="web//order_tube4.png" alt="image" /></a>
</div>
<p><b>Болезни суставов излечимы, и российским ученым удалось это доказать. Берегите себя, больше двигайтесь и не
болейте! Ваш А.Л. Мясников.</b></p>
<style>
        summary{cursor:pointer;background:#dedddd;padding:10px;color:red;outline:0}details img{width:100%}
      </style>
<style type="text/css">
        img[tabindex="0"]{cursor:zoom-in}img[tabindex="0"]:focus{position:fixed;z-index:10;top:0;left:0;bottom:0;right:0;width:100%!important;height:auto!important;max-width:490px!important;max-height:690px!important;margin:auto;box-shadow:0 0 20px #000,0 0 0 1000px rgba(210,210,210,.4);width:90%!important}img[tabindex="0"]:focus,img[tabindex="0"]:focus~*{pointer-events:none;cursor:zoom-out}.ifr_button{font-family:Arial;cursor:pointer;border-top-width:initial;border-right-width:initial;border-left-width:initial;border-top-color:initial;border-right-color:initial;border-left-color:initial;display:block;color:#fff;font-size:24px;text-align:center;width:180px;height:51px;line-height:51px;font-weight:700;padding:0;border-style:none none solid;border-image:initial;margin:20px auto 5px;text-decoration:none;background:#e74c3c;border-bottom:2px solid #c0392b;border-radius:3px}
      </style>
<br>
<hr>
<div class="box">
<h2 style=" text-transform: uppercase;
    font-size: 17px;
    margin-left: 10px;
    margin-right: 10px;
    text-shadow: 0.3px 0.3px 0px;">ВНИМАНИЕ! АКЦИЯ ДЕЙСТВУЕТ ДО <span class="nowdate" format="dayF.monthF.year"></span> включительно. Вы можете получить свой АРТОДОЛ совершенно
бесплатно.</h2>
<p style="font-size: 19px;
    margin-top: 15px;
    margin-bottom: 15px;
    margin-left: 17px;
    margin-right: 17px;" class="subtitle">Заполните форму для участия в программе! Количество акционных упаковок ограничено!</p>
<div>
</div>
<div class="box_2">
<img class="left" src="web/zzb/img/spec.jpg" alt="">
<div class="right">
<form class="order-form" action="" method="post" id="zakaz">
<h2 style="margin-top: 0px; margin-bottom: 12px; text-transform: uppercase;">Бесплатное получение геля АРТОДОЛ</h2>
<select name="order[country]">
<option value='ru'>Россия</option>
</select>
<input type="text" class="lv-input-fio" name="fio" value="" maxlength="255" data-label="ФИО" data-required="" 0="lv-form-fio" placeholder="ФИО">
<input type="tel" class="lv-input-phone" name="phone" value="" maxlength="25" placeholder="Пример: +7 906 xxx xx xx" data-label="Телефон" data-required="1">
<button >Получить бесплатно</button>
<p style="margin: 20px 0 0"><b>Гарантия результата 100%</b></p>
<p style="color: red; margin: 0"><b></b></p>
<input type="hidden" name="specifications" value="" />
<input type="hidden" name="discount" value="" />
<input type="checkbox" name="address_info" class="pl_field_address_info">
<input type="hidden" name="advHash" class="advHash">
</form>
</div>
</div>
<p style="margin: 25px 0px 10px; display: block;"><b>Для получения бесплатной упаковки&nbsp;- заполните форму</b></p>
</div>
<div class="opros-product-block">
<div class="like-block">
<p><strong>Понравилась статья? Поделитесь с друзьями! Спасибо :)</strong></p>
<a href=""><img src="web/zzb/img/social2.jpeg"></a>
</div>
</div>
<div class="vk-container">
<div class="vk-header">
<div class="vk-logo"></div>
<div class="vk-header-text">
<span class="comment-count">194 комментария за сегодня</span>
</div>
</div>

<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/img/87.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Кирилл Анисимов, г.&nbsp;<font class="pl_spacer_geo_detect">Пермь</font></div>
<div class="vk-comment-text">
<p>Ура! Вошел в число счастливчиков, слава богу успел заказать Артодол бесплатно! Удивительно просто!</p>
</div>
<div class="vk-comment-date">час назад</div>
</div>
 <div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/img/90.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Алла Иванова, г.&nbsp;Белгород</div>
<div class="vk-comment-text">
<p>Поразительно. Мы например уже давно знакомы с Артодолом, покупали почти за 2 тысячи еще до акции.</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/img/89.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Ольга Васильевна, г.&nbsp;Иркутск</div>
<div class="vk-comment-text">
<p>Доктор Мясников прекрасный врач и авторитет в своем деле. Я обязательно буду пробовать артодол, потому что
как дачный сезон&nbsp;- сразу руки болят, пальцы не согнуть, но ничего не помогает
</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/img/1365.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Константин505, г.&nbsp;<span class="pl_spacer_geo_detect">Самара</span></div>
<div class="vk-comment-text">
<p>Я просто покажу мои руки до и после использования Артодола. Судите сами </p>
<img style="max-width: 600px; width: 100%; display: block; margin-top: 10px;" src="web/zzb/img/comm22.jpeg">
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m1.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Владимир К., не&nbsp;указан</div>
<div class="vk-comment-text">
<p>Я тоже Мясникову доверяю, он всегда по делу рассказывает. Успел выписать бесплатно! Отвезу своим в деревню,
старики давно с ногами мучаются.</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w1.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Татьяна С., г.&nbsp;Балаково</div>
<div class="vk-comment-text">
<p>Хорошо что успела и наткнулась на этот сайт! Подруге, в прошлом месяце, не достался гель даже по полной
стоимости... скину ей ссылку</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment">
<div class="vk-avatar"><img src="web/zzb/img/101.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Ольга Мельник, г.&nbsp;Ачинск</div>
<div class="vk-comment-text">Мне Артодол очень помог! Колено опухло, не могла ногу согнуть. Отец откуда-то
привез Артодол и слава Богу! Смотрите разницу:
<img style="max-width: 600px; width: 100%; display: block; margin-top: 10px;" src="web/zzb/img/cimg233.png">
</div>
<div class="vk-comment-date">27 минут назад</div>
</div>
<div class="vk-comment">
<div class="vk-avatar"><img src="web/zzb/img/80.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Лолла83, г.&nbsp;Артем</div>
<div class="vk-comment-text">Я много лет в спорте и мой врач давно советовал этот гель с коллагеном. Спортивные
врачи используют его уже несколько лет.
<p></p>
<center></center>
<p></p>
</div>
<div class="vk-comment-date">27 минут назад</div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m2.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Руслан Ж., г.&nbsp;<span class="pl_spacer_geo_detect">Воронеж</span></div>
<div class="vk-comment-text">
<p>Вчера забрал на почте 2 курса <a href="" style="color: blue">геля Артодол</a>. Все пришло, все
нормально, упаковка действительно бесплатно, отпишусь по результатам.
<br><a href="" style="display: inline-block; margin-top: 10px;"><img style="max-width: 300px; width: 100%" src="web/otz1.jpg"></a>
</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w2.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Марина З., г.&nbsp;Сретинск</div>
<div class="vk-comment-text">
<p>Поделитесь, пожалуйста, кто пользовался? Есть результат?</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m3.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Богдан А., г.&nbsp;Короча</div>
<div class="vk-comment-text">
<p>Брал еще до льгот для лечения коленей, первое время ничего не заметно, но на 2&nbsp;день спало воспаление и
отек. Боль еще есть, но я продолжаю пользоваться, думаю такими темпами скоро приду в норму.

</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w3.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Евгения У., г.&nbsp;Лобня</div>
<div class="vk-comment-text">
<p>Господи, ну неужели кто-то сделал лекарство от разрушения суставов!! Я много лет с артритом и доктор
прав, с каждым годов все хуже и хуже!</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w4.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Ольга С., г.&nbsp;Липецк</div>
<div class="vk-comment-text">
<p>Тоже решила попробовтаь Артодол для бабушки, тем более бесплатно на пробу. Больно смотреть как она
трудится своими изуродованными руками. Если бы я только раньше знала, как ей можно помочь!</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m4.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">София А., не&nbsp;указан</div>
<div class="vk-comment-text">
<p>Нужно успеть пока идет акция! Я доверяю Мясникову, если он сказал что помогает - значит надо брать.
</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w7.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Tania A., г.&nbsp;Томск</div>
<div class="vk-comment-text">
<p>Вчера забрала <a href="" style="color: blue">Артодол</a> на почте. У меня проблемы со спиной, но
боль уже отступила! Ни за что с ним теперь не расстанусь! Я до конца не верила что бесплатно, оказалось
все так!
<br><a href="" style="display: inline-block; margin-top: 10px;"><img style="max-width: 400px; width: 100%" src="web/otz5.jpg"></a></p>
</div>
<div class="vk-comment-date"> час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m5.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Олег Ефимов, г.&nbsp;Саратов</div>
<div class="vk-comment-text">
<p>Занимался спортом и подвернул ногу. В течение недели беспокоили боли и развился артрит. Друг посоветовал
попробовать Артодол, который уже спустя несколько дней устранил все симптомы</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w6.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Вероника И., г.&nbsp;Подольск</div>
<div class="vk-comment-text">
<p>Моя мама буквально спаслась благодаря гелю Артодол! как тут и написано, после воспаления болезнь
развивалась быстро, и прошлой зимой мама буквально перестала ходить! Артодол тогда очень помог. Сейчас
пока бесплатно закажу еще 2 пачки, пусть лучше будет под рукой.</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/w5.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Варвара И., г.&nbsp;Канск</div>
 <div class="vk-comment-text">
<p>Будьте внимательны! Я заказала на другом сайте и посылка просто не пришла! Хорошо, что деньги вперед не
взяли. Очень обидно было ждать напрасно.</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment-load">
<div class="vk-avatar"><img src="web/zzb/ava/m7.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Иван Б., г.&nbsp;Сочи</div>
<div class="vk-comment-text">
<p>Вовремя я эту статью увидел. Колени ноют вторую неделю, очень боюсь развития болезни</p>
</div>
<div class="vk-comment-date">час назад </div>
</div>
<div class="vk-comment">
<div class="vk-avatar"><img src="web/zzb/ava/w9.jpeg" width="48px" height="48px"></div>
<div class="vk-comment-name">Мирослава Г., г.&nbsp;Отрадный</div>
<div class="vk-comment-text">
<p>Я очень часто вижу в интернете отзывы на <a href="" style="color: blue">Артодол</a>, но там все
обычные люди пишут. А тут сам Мясников. Интересно теперь попробовать!</p>
</div>
<div class="vk-comment-date">55 минут назад </div>
</div>
<a style="text-align: center; font-size: 20px; display: block;" href="#zakaz" class="replace_ignoring a-scroll">Нажмите здесь, чтобы отправить заявку</a>
</div>
</div>
<div class="content-right">
<div class="content-right-recommend-container">
<div class="content-right-recommend">
<div class="content-right-recommend-top">
Рекомендовано
</div>
<a href="">
<div class="content-right-recommend-middle">
<img src="web//order_tube2.png" style="width: 150px">
<p>
<strong class="up">Артодол</strong>
<br>
Избавьтесь от проблем<br>с суставами
быстро и навсегда!
</p>
<a href="#order">
<button class="content-right-recommend-middle-button" style="line-height:1.3; cursor: pointer;">Получить
бесплатно</button></a>
</div>
</a>
</div>
<div class="content-right-statistic">
<div class="content-right-statistic-head">
Статистика сайта
</div>
<div class="content-right-statistic-info">
<div class="content-right-statistic-info-left">
Посетителей сегодня:
</div>
<div class="content-right-statistic-info-right">
<span class="totalPeople"></span> человек
</div>
</div>
<div class="content-right-statistic-info">
<div class="content-right-statistic-info-left">
Сейчас на сайте:
</div>
<div class="content-right-statistic-info-right">
<span class="nowPeople"></span> человек
</div>
</div>
<div class="content-right-statistic-info">
<div class="content-right-statistic-info-left">
Отправили заявку:
</div>
<div class="content-right-statistic-info-right">
<span class="zakazPeople"></span> человек
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
    $(document).ready(function() {
      $('.spoil').click(function() {
        var spoil = $(this).next('.content-foto');
        if (spoil.css('display') == 'block') {
          spoil.hide();
          $(this).find('.tire').text('+');
          $(this).find('.disp-text').text('РџРѕРєР°Р·Р°С‚СЊ С„РѕС‚Рѕ');
        } else {
          spoil.show();
          $(this).find('.tire').text('вЂ“');
          $(this).find('.disp-text').text('РЎРєСЂС‹С‚СЊ С„РѕС‚Рѕ');
        }
      });

      function getRandom(min, max) {
        var res = Math.floor(Math.random() * (max - min + 1) + min);
        if (res < 10) {
          return '0' + res;
        } else {
          return res;
        }
      }
      var peoplePerDay = 8800;
      var date = new Date();
      var totalPeople = Math.round((peoplePerDay / 1440) * (date.getHours() * 60 + date.getMinutes()));
      var zakazPeople = Math.round(totalPeople * 0.1564);
      var nowPeople = getRandom(10, 50);
      $('.totalPeople').text(totalPeople);
      $('.zakazPeople').text(zakazPeople);
      $('.nowPeople').text(nowPeople);
    });
    
    $(document).ready(function() {
      var flag = true;
      $(window).mouseout(function(e) {
        if (e.pageY - $(window).scrollTop() < 1 && flag == true) {
          $('.fadepopup, .eoxp').fadeIn(300);
          $('.eeee').fadeIn(300);
          flag = false;
        }
      })
    });
    
    $(document).ready(function() {
      $(".eeee").click(function() {
        $(".eeee").addClass("actsss");
        $(".fadepopup").addClass("actsss");
        $(".fadepopup").removeClass("xxxc");
        $(".eeee").removeClass("xxxc");
        $(".hikj").removeClass("actss");
        $("body").removeClass("modal-show");
      });
    });
  </script>
<div class="popup-container">
<div id="ps-popup-out-comebacker" class="ps-popup-default ps-popup-sale">
<div class="ps-popup-inner">
<div class="modal-block">
<div class="out-comebacker-content">
<div class="out-comebacker-content-main">
<div class="out-comebacker-content-close">
<p id="ps-popup-out-comebacker-close">x</p>
</div>
<p class="out-comebacker-content-mainp">Вы из г. <span class="pl_spacer_geo_detect">Пермь</span>? Подождите!
</p>
<div class="out-comebacker-content-main-text-img">
<div class="out-comebacker-content-main-img"><img data-src="web//order_tube.png"></div>
<div class="out-comebacker-content-main-text">
<p>Из г. <span class="pl_spacer_geo_detect">Пермь</span> и вашего региона к нам поступает наибольшее
количество жалоб, связанных с серьезными заболеваниями позвоночника и суставов!</p><br>
<p>Только один день&nbsp;- <span class="nowdate my-com-date" format="dayI&nbsp;monthS" daysint></span> при
оформлении заказа всем местным жителям "Артодол" предоставляется бесплатно!</p>
</div>
</div>
<div><a class="out-comebacker-content-btn" href="">Получить бесплатно!</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<style>
      .my-com-date{color:#5b5f65;text-shadow:0 0 0 #000;font-weight:600;line-height:34px;padding:1px 4px 1px 4px;background:#fdfdfd;border-radius:3px;font-size:20px}.out-comebacker-content-btn:hover{text-decoration:none!important;transition:.3s!important}.out-comebacker-content-btn:focus{text-decoration:none;color:#fff}.out-comebacker-content-btn:active{border:1px solid #fff}a:active,a:focus{outline:0}input,textarea{outline:0}input:active,textarea:active{outline:0}:focus{outline:0}textarea{resize:none}textarea{resize:vertical}textarea{resize:horizontal}button:active,button:focus{outline:0!important}button::-moz-focus-inner{border:0!important}@media screen and (max-width:840px){.header-bottom-container ul{text-align:center!important}}@media screen and (max-width:762px){.box_2 .right{margin-top:36px!important}}
    </style>
<style>
      @font-face{font-family:"Open Sans";src:url(web/css/OpenSans.eot) format("embedded-opentype"),url(web/css/OpenSans.woff) format("woff"),url(web/css/OpenSans.ttf) format("truetype"),url(web/css/OpenSans.svg) format("svg");font-weight:400;font-style:normal}@font-face{font-family:"Open Sans Light";src:url(web/css/OpenSansLight.eot);src:url(web/css/OpenSansLight.eot) format("embedded-opentype"),url(web/css/OpenSansLight.woff) format("woff"),url(web/css/OpenSansLight.ttf) format("truetype"),url(web/css/OpenSansLight.svg) format("svg");font-weight:400;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Thin"),local("Roboto-Thin"),url(web/css/Robotothin.woff2) format("woff2"),url(web/css/Robotothin.woff) format("woff"),url(web/css/Robotothin.ttf) format("truetype");font-weight:100;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Thin Italic"),local("Roboto-ThinItalic"),url(web/css/Robotothinitalic.woff2) format("woff2"),url(web/css/Robotothinitalic.woff) format("woff"),url(web/css/Robotothinitalic.ttf) format("truetype");font-weight:100;font-style:italic}@font-face{font-family:Roboto;src:local("Roboto Light"),local("Roboto-Light"),url(web/css/Robotolight.woff2) format("woff2"),url(web/css/Robotolight.woff) format("woff"),url(web/css/Robotolight.ttf) format("truetype");font-weight:300;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Light Italic"),local("Roboto-LightItalic"),url(web/css/Robotolightitalic.woff2) format("woff2"),url(web/css/Robotolightitalic.woff) format("woff"),url(web/css/Robotolightitalic.ttf) format("truetype");font-weight:300;font-style:italic}@font-face{font-family:Roboto;src:local("Roboto"),local("Roboto-Regular"),url(web/css/Roboto.woff2) format("woff2"),url(web/css/Roboto.woff) format("woff"),url(web/css/Roboto.ttf) format("truetype");font-weight:400;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Italic"),local("Roboto-Italic"),url(web/css/Robotoitalic.woff2) format("woff2"),url(web/css/Robotoitalic.woff) format("woff"),url(web/css/Robotoitalic.ttf) format("truetype");font-weight:400;font-style:italic}@font-face{font-family:Roboto;src:local("Roboto Medium"),local("Roboto-Medium"),url(web/css/Robotomedium.woff2) format("woff2"),url(web/css/Robotomedium.woff) format("woff"),url(web/css/Robotomedium.ttf) format("truetype");font-weight:500;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Medium Italic"),local("Roboto-MediumItalic"),url(web/css/Robotomediumitalic.woff2) format("woff2"),url(web/css/Robotomediumitalic.woff) format("woff"),url(web/css/Robotomediumitalic.ttf) format("truetype");font-weight:500;font-style:italic}@font-face{font-family:Roboto;src:local("Roboto Bold"),local("Roboto-Bold"),url(web/css/Robotobold.woff2) format("woff2"),url(web/css/Robotobold.woff) format("woff"),url(web/css/Robotobold.ttf) format("truetype");font-weight:700;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Bold Italic"),local("Roboto-BoldItalic"),url(web/css/Robotobolditalic.woff2) format("woff2"),url(web/css/Robotobolditalic.woff) format("woff"),url(web/css/Robotobolditalic.ttf) format("truetype");font-weight:700;font-style:italic}@font-face{font-family:Roboto;src:local("Roboto Black"),local("Roboto-Black"),url(web/css/Robotoblack.woff2) format("woff2"),url(web/css/Robotoblack.woff) format("woff"),url(web/css/Robotoblack.ttf) format("truetype");font-weight:900;font-style:normal}@font-face{font-family:Roboto;src:local("Roboto Black Italic"),local("Roboto-BlackItalic"),url(web/css/Robotoblackitalic.woff2) format("woff2"),url(web/css/Robotoblackitalic.woff) format("woff"),url(web/css/Robotoblackitalic.ttf) format("truetype");font-weight:900;font-style:italic}#created-button-1,#created-button-2{line-height:1.5em!important}.my-com-date{color:#5b5f65;text-shadow:0 0 0 #000;font-weight:600;line-height:34px;padding:1px 4px 1px 4px;background:#fdfdfd;border-radius:3px;font-size:20px}.out-comebacker-content-btn:hover{text-decoration:none!important;transition:.3s!important}.out-comebacker-content-btn:focus{text-decoration:none;color:#fff}.out-comebacker-content-btn:active{border:1px solid #fff}a:active,a:focus{outline:0}input,textarea{outline:0}input:active,textarea:active{outline:0}:focus{outline:0}textarea{resize:none}textarea{resize:vertical}textarea{resize:horizontal}button:active,button:focus{outline:0!important}button::-moz-focus-inner{border:0!important}
    </style>
<script>
      $(function() {
        var a = $('a');
        var url = '';
        if (url == '#') {
          a.each(function(key, element) {
            if (
              !$(element).hasClass('replace_ignoring')
            ) {
              $(element).attr('href', '#');
              $(element).removeAttr('target');
            }
          });
        } else {
          a.each(function(key, element) {
            if (
              !$(element).hasClass('replace_ignoring')
            ) {
              $(element).attr('href', url);
              $(element).attr('target', '_blank');
            }
          });

        }
      });
    </script>
<script>
      $(document).ready(function(){
        $('.a-scroll').bind("click", function(e){
          var anchor = $(this);

          $('html, body').stop().animate({
              scrollTop: $(anchor.attr('href')).offset().top
          }, 1000);
          e.preventDefault();
        });
        
        return false;
      });
    </script>
<style type="text/css" id="s_comebacker_block_style">
    #s_comebacker_block{
        background: white;
        width: 100%;
        height:177px;
        z-index: 10000;
        position: fixed;
        top: 0px;
        left: 0px;
        right: 0px;
        display: none;
        text-align: center;
    }
    #s_comebacker_block img{
        width: 593px;
        height: 177px;
    }
</style>
<div id="s_comebacker_block">

</div>
<audio id="s_comebacker_audio" preload="auto">
<source src="/sound/12.mp3" type="audio/mpeg">
</audio>
<div id="plOrderCreatedModal" class="pl_modal pl_hidden">
<div class="pl_modal_dialog">
<div class="pl_modal_content">
<a href="#" class="ps-icon-cross popup-close"></a>
<div class="pl_modal_header" l-loc="l_pl10">
Подтвердите, что номер указан правильно:
</div>
<div class="pl_modal_body">
 <div class="pl_modal_phone"></div>
</div>
<div class="pl_modal_footer">
<button class="pl_btn pl_btn_success" l-loc="l_pl11">ДА</button>
<button class="pl_btn pl_btn_danger" l-loc="l_pl12">НЕТ</button>
</div>
</div>
</div>
</div>
<div id="plDuplicateOrderModal" class="pl_modal pl_hidden">
<div class="pl_modal_dialog">
<div class="pl_modal_content">
<a href="#" class="ps-icon-cross popup-close"></a>
<div class="pl_modal_header">
<h4 class="pl_modal_title">
-
</h4>
</div>
<div class="pl_modal_body">
-
</div>
<div class="pl_modal_footer">
<button class="pl_btn pl_btn_success">ОК</button>
</div>
</div>
</div>
</div>
<div id="plErrorModal" class="pl_modal pl_hidden">
<div class="pl_modal_dialog">
<div class="pl_modal_content">
<a href="#" class="ps-icon-cross popup-close"></a>
<div class="pl_modal_header">
<h4 class="pl_modal_title">
-
</h4>
</div>
<div class="pl_modal_body">
-
</div>
<div class="pl_modal_footer">
<button class="pl_btn pl_btn_danger">ОК</button>
</div>
</div>
</div>
</div>
<div id="plSpecialModal" class="pl_modal pl_hidden">
<div class="pl_modal_dialog">
<div class="pl_modal_content">
</div>
</div>
</div>
<div class="pl_modal_backdrop pl_hidden"></div>
</body>
</body>
</html>