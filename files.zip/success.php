<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/success/favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="/success/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,500,300italic,700&amp;subset=latin,cyrillic"
          rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lobster">
    <link media="all" href="/success/css/index.css" rel="stylesheet" type="text/css">
    <title>Спасибо, Ваш заказ принят!</title>
</head>
<body class="man">
<div class="section block-1">
    <div class="wrap">
        <img src="/success/img/call-girl.png" alt="">
        <div class="top-title">
            <h2>Спасибо, Ваш заказ принят!</h2>
            <div>Наш специалист свяжется с Вами в течение 30 минут.</div>
        </div>
    </div>
</div>

<div class="section block-2"></div>
<div class="section block-3">
    <div class="container">
        <div class="center col-sm-offset-1 col-sm-10">
            Мы ответим на все интересующие Вас вопросы и поможем оформить заказ.
        </div>
    </div>
</div>
</body>
</html>